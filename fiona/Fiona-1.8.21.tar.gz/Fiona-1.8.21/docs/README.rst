.. include:: ../README.rst

.. include:: ../CHANGES.txt

.. include:: ../CREDITS.txt
